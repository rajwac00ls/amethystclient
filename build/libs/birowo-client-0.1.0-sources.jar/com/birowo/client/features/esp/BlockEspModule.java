package com.birowo.client.features.esp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.lwjgl.glfw.GLFW;
import com.birowo.client.core.config.ConfigValue;
import com.birowo.client.core.config.ConfigValues;
import com.birowo.client.core.keybind.KeyBindFactory;
import com.birowo.client.core.module.Module;
import com.birowo.client.core.module.ModuleCategory;
import com.birowo.client.platform.render.ShapeRenderer;
import com.birowo.client.platform.render.WorldLayers;
import com.birowo.client.platform.render.WorldRenderable;
import com.birowo.client.platform.world.BlockPreset;
import com.birowo.client.platform.world.BlockScanner;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Draws a box around the blocks that are worth looking for.
 *
 * <p>The blocks are looked for in the chunks around the player. A chunk holds thousands of
 * blocks, so the chunks are not looked through again and again: the result of a chunk is kept
 * until it grows old, and only a few chunks are looked through in one tick, so that the frame
 * rate does not suffer while the player walks around.
 *
 * <p>The result of a chunk grows old after a while, because a block that was mined and a block
 * that was placed are not noticed until the chunk is looked through again.
 *
 * <p>The boxes are drawn twice when they are asked to shine through walls: once with the layer
 * that ignores the depth of the world, and once with the layer of the game, so that the edges of
 * a block that is in sight are drawn over the world rather than through it.
 */
public final class BlockEspModule extends Module implements WorldRenderable {
	/**
	 * How many chunks may be looked through in one tick.
	 */
	private static final int CHUNKS_PER_TICK = 4;

	/**
	 * How many ticks the result of a chunk is trusted, in ticks.
	 */
	private static final long REVALIDATE_TICKS = 100L;

	/**
	 * The largest radius of chunks that may be looked through, in chunks.
	 */
	private static final int MAX_CHUNK_RADIUS = 12;

	/**
	 * The largest number of blocks that may be shown at once.
	 */
	private static final int MAX_TARGETS = 8192;

	private final ConfigValue<BlockPreset> preset = setting(ConfigValues.ofEnum("preset", BlockPreset.VALUABLE));
	private final ConfigValue<Integer> chunkRadius = setting(ConfigValues.ofInt("chunkRadius", 4));
	private final ConfigValue<Integer> maxTargets = setting(ConfigValues.ofInt("maxTargets", 1024));
	private final ConfigValue<Integer> color = setting(ConfigValues.ofColor("color", 0xCCFF3B3B));
	private final ConfigValue<Boolean> throughWalls = setting(ConfigValues.ofBoolean("throughWalls", true));

	/**
	 * The result of the chunks that have been looked through, by the place of the chunk.
	 */
	private final Map<Long, Entry> chunks = new HashMap<>();

	/**
	 * The blocks that are shown this frame, published by the tick and read by the render thread.
	 */
	private volatile List<class_238> targets = List.of();

	/**
	 * The number of ticks the module has been running, used to tell how old a result is.
	 */
	private long tick;

	/**
	 * @param keyBinds the factory used to register this module's key binding
	 */
	public BlockEspModule(KeyBindFactory keyBinds) {
		super("blockesp", "BlockESP", "Draws a box around the blocks that are worth looking for.",
				ModuleCategory.RENDER);

		keyBinds.bind("blockesp", "key.birowo.blockesp", GLFW.GLFW_KEY_B, this::toggle);
	}

	@Override
	public void onTick() {
		class_310 client = class_310.method_1551();
		class_746 player = client.field_1724;
		class_638 world = client.field_1687;

		if (player == null || world == null) {
			targets = List.of();
			return;
		}

		long now = ++tick;
		int radius = Math.max(0, Math.min(MAX_CHUNK_RADIUS, chunkRadius.value()));
		int centerX = (int) Math.floor(player.method_23317()) >> 4;
		int centerZ = (int) Math.floor(player.method_23321()) >> 4;
		Set<class_2248> wanted = preset.value().blocks();

		chunks.keySet().removeIf(key -> outside(key, centerX, centerZ, radius));

		int scanned = 0;

		for (int dx = -radius; dx <= radius && scanned < CHUNKS_PER_TICK; dx++) {
			for (int dz = -radius; dz <= radius && scanned < CHUNKS_PER_TICK; dz++) {
				long key = class_1923.method_8331(centerX + dx, centerZ + dz);
				Entry entry = chunks.get(key);

				if (entry != null && now - entry.scannedAt() <= REVALIDATE_TICKS) {
					continue;
				}

				class_2791 chunk = world.method_8402(centerX + dx, centerZ + dz, class_2806.field_12803, false);

				if (chunk == null) {
					// The chunk is not loaded yet; there is nothing to look through.
					chunks.remove(key);
					continue;
				}

				chunks.put(key, new Entry(now, BlockScanner.scan(world, chunk, wanted)));
				scanned++;
			}
		}

		targets = collect(player);
	}

	@Override
	public void onWorldRender(WorldRenderContext context) {
		List<class_238> snapshot = targets;

		if (snapshot.isEmpty()) {
			return;
		}

		class_4587 matrices = context.matrices();

		if (matrices == null) {
			return;
		}

		class_310 client = class_310.method_1551();
		class_4184 camera = client.field_1773.method_19418();
		class_243 cameraPos = camera.method_71156();

		float lineWidth = client.method_22683().method_75291();
		int argb = color.value();

		class_4588 throughWallLines = null;

		if (throughWalls.value()) {
			throughWallLines = context.consumers().method_73477(WorldLayers.linesNoDepth());
		}

		class_4588 visible = context.consumers().method_73477(class_12249.method_76015());
		class_4587.class_4665 entry = matrices.method_23760();

		for (class_238 box : snapshot) {
			double minX = box.field_1323 - cameraPos.field_1352;
			double minY = box.field_1322 - cameraPos.field_1351;
			double minZ = box.field_1321 - cameraPos.field_1350;
			double maxX = box.field_1320 - cameraPos.field_1352;
			double maxY = box.field_1325 - cameraPos.field_1351;
			double maxZ = box.field_1324 - cameraPos.field_1350;

			if (throughWallLines != null) {
				ShapeRenderer.drawBoxEdges(throughWallLines, entry, minX, minY, minZ, maxX, maxY, maxZ,
						argb, lineWidth);
			}

			ShapeRenderer.drawBoxEdges(visible, entry, minX, minY, minZ, maxX, maxY, maxZ, argb, lineWidth);
		}
	}

	@Override
	protected void onDisable() {
		chunks.clear();
		targets = List.of();
	}

	/**
	 * Gathers the blocks that are to be shown, the ones that are nearest to the player first.
	 *
	 * @param player the player the blocks are looked for around
	 * @return the blocks that are to be shown
	 */
	private List<class_238> collect(class_746 player) {
		int limit = Math.max(1, Math.min(MAX_TARGETS, maxTargets.value()));
		List<Map.Entry<Long, Entry>> ordered = new ArrayList<>(chunks.entrySet());

		ordered.sort((first, second) -> Double.compare(distance(first.getKey(), player),
				distance(second.getKey(), player)));

		List<class_238> found = new ArrayList<>();

		for (Map.Entry<Long, Entry> chunk : ordered) {
			for (class_238 box : chunk.getValue().boxes()) {
				found.add(box);

				if (found.size() >= limit) {
					return List.copyOf(found);
				}
			}
		}

		return List.copyOf(found);
	}

	/**
	 * @param key     the place of a chunk
	 * @param centerX the column of chunks the player is in
	 * @param centerZ the row of chunks the player is in
	 * @param radius  the radius of the chunks that are looked through, in chunks
	 * @return whether the chunk lies outside the radius
	 */
	private static boolean outside(long key, int centerX, int centerZ, int radius) {
		return Math.abs(class_1923.method_8325(key) - centerX) > radius
				|| Math.abs(class_1923.method_8332(key) - centerZ) > radius;
	}

	/**
	 * @param key    the place of a chunk
	 * @param player the player the distance is measured from
	 * @return the distance between the player and the middle of the chunk, in blocks
	 */
	private static double distance(long key, class_746 player) {
		double dx = class_1923.method_8325(key) * 16 + 8 - player.method_23317();
		double dz = class_1923.method_8332(key) * 16 + 8 - player.method_23321();

		return dx * dx + dz * dz;
	}

	/**
	 * The result of looking through one chunk.
	 *
	 * @param scannedAt the tick the chunk was looked through in
	 * @param boxes     the blocks that were found, in world coordinates
	 */
	private record Entry(long scannedAt, List<class_238> boxes) {
	}
}
