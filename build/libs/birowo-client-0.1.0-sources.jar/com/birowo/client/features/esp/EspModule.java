package com.birowo.client.features.esp;

import java.util.List;

import org.lwjgl.glfw.GLFW;
import com.birowo.client.core.config.ConfigValue;
import com.birowo.client.core.config.ConfigValues;
import com.birowo.client.core.keybind.KeyBindFactory;
import com.birowo.client.core.module.Module;
import com.birowo.client.core.module.ModuleCategory;
import com.birowo.client.platform.entity.EntityQueries;
import com.birowo.client.platform.render.ShapeRenderer;
import com.birowo.client.platform.render.WorldLayers;
import com.birowo.client.platform.render.WorldRenderable;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Draws a wireframe box around nearby entities.
 *
 * <p>The outline is drawn twice when it is asked to shine through walls: once with the layer that
 * ignores the depth of the world, so that the box of an entity behind a wall stays visible, and
 * once with the layer of the game, so that the edges of the box that are actually in sight are
 * drawn over the body of the entity rather than through it. The copy that shines through walls is
 * the fainter of the two, which keeps the body of the entity readable.
 *
 * <p>The entity query runs on the client tick, not on the render thread: world lookups are not
 * safe to perform while rendering. The box itself is measured while rendering, so that it follows
 * an entity that moves instead of trailing it by a tick.
 */
public final class EspModule extends Module implements WorldRenderable {
	/**
	 * How far the outline is kept away from the body of the entity, in blocks. Without the gap
	 * the lines and the surface of the entity share the same depth and fight each other, which
	 * makes the outline flicker.
	 */
	private static final float OUTLINE_EPSILON = 0.02F;

	/**
	 * The opacity of the copy of the outline that shines through walls, between zero and one.
	 */
	private static final float THROUGH_WALLS_ALPHA = 0.45F;

	private final ConfigValue<Double> range = setting(ConfigValues.ofDouble("range", 64.0));
	private final ConfigValue<Boolean> playersOnly = setting(ConfigValues.ofBoolean("playersOnly", true));
	private final ConfigValue<Integer> color = setting(ConfigValues.ofColor("color", 0xFFFF5555));
	private final ConfigValue<Boolean> throughWalls = setting(ConfigValues.ofBoolean("throughWalls", false));

	/**
	 * The entities to outline this frame, published by the tick and read by the render thread.
	 *
	 * <p>Replaced wholesale rather than mutated in place: the client thread and the render thread
	 * are different threads, and an immutable list swapped atomically is the only way for the
	 * renderer to read a consistent set without locking.
	 */
	private volatile List<class_1297> targets = List.of();

	/**
	 * @param keyBinds the factory used to register this module's key binding
	 */
	public EspModule(KeyBindFactory keyBinds) {
		super("esp", "ESP", "Draws an outline around nearby entities.", ModuleCategory.RENDER);

		keyBinds.bind("esp", "key.birowo.esp", GLFW.GLFW_KEY_H, this::toggle);
	}

	@Override
	public void onTick() {
		class_310 client = class_310.method_1551();
		class_746 player = client.field_1724;
		class_638 world = client.field_1687;

		if (player == null || world == null) {
			targets = List.of();
			return;
		}

		targets = List.copyOf(EntityQueries.entitiesInRange(world, player, range.value(), playersOnly.value(),
				entity -> entity != player && entity.method_5805() && !entity.method_7325()));
	}

	@Override
	public void onWorldRender(WorldRenderContext context) {
		List<class_1297> snapshot = targets;

		if (snapshot.isEmpty()) {
			return;
		}

		class_4587 matrices = context.matrices();

		if (matrices == null) {
			return;
		}

		class_310 client = class_310.method_1551();
		class_4184 camera = client.field_1773.method_19418();
		class_243 cameraPos = camera.method_71156();

		float lineWidth = client.method_22683().method_75291();
		int argb = color.value();

		class_4588 throughWallLines = null;

		if (throughWalls.value()) {
			throughWallLines = context.consumers().method_73477(WorldLayers.linesNoDepth());
		}

		class_4588 visible = context.consumers().method_73477(class_12249.method_76015());
		class_4587.class_4665 entry = matrices.method_23760();

		for (class_1297 target : snapshot) {
			double x = target.method_23317() - cameraPos.field_1352;
			double y = target.method_23318() - cameraPos.field_1351;
			double z = target.method_23321() - cameraPos.field_1350;
			double half = target.method_17681() / 2.0D;

			double minX = x - half - OUTLINE_EPSILON;
			double maxX = x + half + OUTLINE_EPSILON;
			double minY = y - OUTLINE_EPSILON;
			double maxY = y + target.method_17682() + OUTLINE_EPSILON;
			double minZ = z - half - OUTLINE_EPSILON;
			double maxZ = z + half + OUTLINE_EPSILON;

			if (throughWallLines != null) {
				ShapeRenderer.drawBoxEdges(throughWallLines, entry, minX, minY, minZ, maxX, maxY, maxZ,
						fade(argb, THROUGH_WALLS_ALPHA), lineWidth);
			}

			ShapeRenderer.drawBoxEdges(visible, entry, minX, minY, minZ, maxX, maxY, maxZ, argb, lineWidth);
		}
	}

	@Override
	protected void onDisable() {
		targets = List.of();
	}

	/**
	 * @param argb  the colour, with its own opacity
	 * @param alpha the opacity to apply, between zero and one
	 * @return the same colour with the given opacity
	 */
	private static int fade(int argb, float alpha) {
		int opacity = Math.round(((argb >>> 24) & 0xFF) * alpha);
		return (opacity << 24) | (argb & 0x00FFFFFF);
	}
}
