package com.birowo.client.features.esp;

import org.lwjgl.glfw.GLFW;
import com.birowo.client.core.config.ConfigValue;
import com.birowo.client.core.config.ConfigValues;
import com.birowo.client.core.event.EventBus;
import com.birowo.client.core.keybind.KeyBindFactory;
import com.birowo.client.core.module.Module;
import com.birowo.client.core.module.ModuleCategory;
import com.birowo.client.platform.event.TargetChangedEvent;
import com.birowo.client.platform.render.ShapeRenderer;
import com.birowo.client.platform.render.WorldLayers;
import com.birowo.client.platform.render.WorldRenderable;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/**
 * Marks the entity that is being attacked.
 *
 * <p>Three things are drawn around the target: a ring that floats up and down around it, a
 * translucent fill of its body that fades from the feet to the head, and a cone that stands on
 * its head. The fill is faint on purpose — it is there to tell where the target is, not to light
 * the scene up.
 *
 * <p>Everything is drawn at the place the target is drawn at, which is between two ticks. A
 * target that runs therefore does not make the shapes jump once per tick.
 *
 * <p>The ring follows the target with a delay of its own, so that it glides after the target
 * instead of sticking to it, which keeps the movement smooth when the target runs.
 *
 * <p>The target is announced by the combat module through the event bus, so that the two modules
 * do not have to know each other.
 */
public final class TargetEspModule extends Module implements WorldRenderable {
	/**
	 * The number of straight lines the ring is made of.
	 */
	private static final int SEGMENTS = 48;

	/**
	 * The number of triangles the cone is made of.
	 */
	private static final int CONE_SEGMENTS = 24;

	/**
	 * The rate at which the ring catches up with the target, per second.
	 */
	private static final float FOLLOW_RATE = 16.0F;

	/**
	 * The longest frame the animation may be advanced by, in seconds.
	 */
	private static final float MAX_FRAME_SECONDS = 0.1F;

	/**
	 * The number of radians in a full turn.
	 */
	private static final float TAU = (float) (Math.PI * 2.0D);

	/**
	 * The number of radians in a degree.
	 */
	private static final float DEGREES_TO_RADIANS = (float) (Math.PI / 180.0D);

	/**
	 * The gap between the head of the target and the bottom of the cone, in blocks. It keeps the
	 * cone from flickering against the head.
	 */
	private static final double CONE_GAP = 0.06D;

	private final ConfigValue<Double> radius = setting(ConfigValues.ofDouble("radius", 0.7));
	private final ConfigValue<Double> amplitude = setting(ConfigValues.ofDouble("amplitude", 0.12));
	private final ConfigValue<Double> speed = setting(ConfigValues.ofDouble("speed", 2.0));
	private final ConfigValue<Integer> color = setting(ConfigValues.ofColor("color", 0xFFFFFFFF));
	private final ConfigValue<Integer> fillColor = setting(ConfigValues.ofColor("fillColor", 0x30A0A0A0));
	private final ConfigValue<Boolean> throughWalls = setting(ConfigValues.ofBoolean("throughWalls", false));
	private final ConfigValue<Boolean> coneHat = setting(ConfigValues.ofBoolean("coneHat", true));
	private final ConfigValue<Integer> coneColor = setting(ConfigValues.ofColor("coneColor", 0xFFE8E8E8));
	private final ConfigValue<Double> coneHeight = setting(ConfigValues.ofDouble("coneHeight", 0.55));
	private final ConfigValue<Double> coneRadius = setting(ConfigValues.ofDouble("coneRadius", 0.42));
	private final ConfigValue<Double> coneOpacity = setting(ConfigValues.ofDouble("coneOpacity", 0.9));
	private final ConfigValue<Double> coneRotation = setting(ConfigValues.ofDouble("coneRotation", 20.0));

	private volatile class_1297 target;
	private class_1297 followed;

	private double ringX;
	private double ringY;
	private double ringZ;
	private float phase;
	private float conePhase;
	private long previousFrameNanos;

	/**
	 * @param eventBus the bus the change of the target is announced on
	 * @param keyBinds the factory used to register this module's key binding
	 */
	public TargetEspModule(EventBus eventBus, KeyBindFactory keyBinds) {
		super("targetesp", "TargetESP", "Marks the entity that is attacked.", ModuleCategory.RENDER);

		eventBus.subscribe(TargetChangedEvent.class, event -> this.target = event.target());

		keyBinds.bind("targetesp", "key.birowo.targetesp", GLFW.GLFW_KEY_Y, this::toggle);
	}

	@Override
	public void onWorldRender(WorldRenderContext context) {
		class_1297 entity = target;

		if (entity == null || !entity.method_5805()) {
			return;
		}

		class_4587 matrices = context.matrices();

		if (matrices == null) {
			return;
		}

		float delta = frameDelta();

		phase += delta * speed.value().floatValue() * TAU;

		if (phase > TAU) {
			phase -= TAU;
		}

		conePhase += delta * coneRotation.value().floatValue() * DEGREES_TO_RADIANS;

		if (conePhase > TAU) {
			conePhase -= TAU;
		}

		class_310 client = class_310.method_1551();
		class_4184 camera = client.field_1773.method_19418();
		class_243 cameraPos = camera.method_71156();

		// The place the target is drawn at, which is between two ticks.
		float tickDelta = client.method_61966().method_60637(false);
		class_243 position = entity.method_30950(tickDelta);

		if (entity != followed) {
			followed = entity;
			ringX = position.field_1352;
			ringY = position.field_1351;
			ringZ = position.field_1350;
		} else {
			float factor = 1.0F - (float) Math.exp(-FOLLOW_RATE * delta);

			ringX += (position.field_1352 - ringX) * factor;
			ringY += (position.field_1351 - ringY) * factor;
			ringZ += (position.field_1350 - ringZ) * factor;
		}

		float lineWidth = client.method_22683().method_75291();
		int argb = color.value();
		int fill = fillColor.value();

		class_4587.class_4665 entry = matrices.method_23760();

		boolean throughWalls = this.throughWalls.value();

		class_4588 fillConsumer = context.consumers()
				.method_73477(throughWalls ? WorldLayers.filledBoxNoDepth() : WorldLayers.filledBox());
		class_4588 lineConsumer = context.consumers()
				.method_73477(throughWalls ? WorldLayers.linesNoDepth() : class_12249.method_76015());

		double half = entity.method_17681() / 2.0D;
		double height = entity.method_17682();

		double minX = position.field_1352 - half - cameraPos.field_1352;
		double minY = position.field_1351 - cameraPos.field_1351;
		double minZ = position.field_1350 - half - cameraPos.field_1350;
		double maxX = position.field_1352 + half - cameraPos.field_1352;
		double maxY = position.field_1351 + height - cameraPos.field_1351;
		double maxZ = position.field_1350 + half - cameraPos.field_1350;

		// The fill of the body fades out towards the head, so that the head stays readable.
		ShapeRenderer.drawBoxFill(fillConsumer, entry, minX, minY, minZ, maxX, maxY, maxZ, fill, fade(fill, 0.0F));
		ShapeRenderer.drawBoxEdges(lineConsumer, entry, minX, minY, minZ, maxX, maxY, maxZ, argb, lineWidth);

		// The ring floats around the middle of the target.
		float bob = (float) Math.sin(phase) * amplitude.value().floatValue();
		double ringHeight = ringY - cameraPos.field_1351 + height * 0.5D + bob;

		ShapeRenderer.drawRing(lineConsumer, entry, ringX - cameraPos.field_1352, ringHeight, ringZ - cameraPos.field_1350,
				radius.value(), argb, lineWidth, SEGMENTS);

		if (coneHat.value()) {
			double coneBase = position.field_1351 + height + CONE_GAP - cameraPos.field_1351;
			int cone = fade(coneColor.value(), coneOpacity.value().floatValue());

			ShapeRenderer.drawCone(fillConsumer, entry, position.field_1352 - cameraPos.field_1352, coneBase,
					position.field_1350 - cameraPos.field_1350, coneRadius.value(), coneHeight.value(), cone, conePhase,
					CONE_SEGMENTS);
			ShapeRenderer.drawRing(lineConsumer, entry, position.field_1352 - cameraPos.field_1352, coneBase,
					position.field_1350 - cameraPos.field_1350, coneRadius.value(), argb, lineWidth, SEGMENTS);
		}
	}

	@Override
	protected void onDisable() {
		followed = null;
		phase = 0.0F;
		conePhase = 0.0F;
		previousFrameNanos = 0L;
	}

	/**
	 * @return the time since the previous frame, in seconds
	 */
	private float frameDelta() {
		long now = System.nanoTime();
		float elapsed = previousFrameNanos == 0L ? 0.0F : (now - previousFrameNanos) / 1_000_000_000.0F;
		previousFrameNanos = now;

		return Math.min(elapsed, MAX_FRAME_SECONDS);
	}

	/**
	 * @param argb  the colour, with its own opacity
	 * @param alpha the factor to apply to the opacity, between zero and one
	 * @return the same colour with the scaled opacity
	 */
	private static int fade(int argb, float alpha) {
		float factor = Math.max(0.0F, Math.min(1.0F, alpha));
		int opacity = Math.round(((argb >>> 24) & 0xFF) * factor);
		return (opacity << 24) | (argb & 0x00FFFFFF);
	}
}
