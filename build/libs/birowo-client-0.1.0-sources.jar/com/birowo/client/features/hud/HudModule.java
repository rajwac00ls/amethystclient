package com.birowo.client.features.hud;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.lwjgl.glfw.GLFW;
import com.birowo.client.core.config.ConfigValue;
import com.birowo.client.core.config.ConfigValues;
import com.birowo.client.core.event.EventBus;
import com.birowo.client.core.event.ModuleToggleEvent;
import com.birowo.client.core.keybind.KeyBindFactory;
import com.birowo.client.core.module.Module;
import com.birowo.client.core.module.ModuleCategory;
import com.birowo.client.core.module.ModuleManager;
import com.birowo.client.platform.combat.PvpVersionService;
import com.birowo.client.platform.render.HudRenderable;

/**
 * Draws a small status readout on the HUD.
 *
 * <p>Every line of the readout is built only when its content changes, so that the render path
 * does not build a text every frame. The frame rate is the exception: it is read a few times a
 * second, because a number that changes that fast cannot be read anyway.
 */
public final class HudModule extends Module implements HudRenderable {
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int ACCENT_COLOR = 0xFF7FE7FF;
	private static final int LINE_HEIGHT = 10;

	/**
	 * The number of frames between two readings of the frame rate.
	 */
	private static final int FPS_INTERVAL_FRAMES = 10;

	private final ConfigValue<Integer> x = setting(ConfigValues.ofInt("x", 4));
	private final ConfigValue<Integer> y = setting(ConfigValues.ofInt("y", 4));
	private final ConfigValue<Boolean> showFps = setting(ConfigValues.ofBoolean("showFps", true));
	private final ConfigValue<Boolean> showCoordinates = setting(ConfigValues.ofBoolean("showCoordinates", true));
	private final ConfigValue<Boolean> showModules = setting(ConfigValues.ofBoolean("showModules", true));
	private final ConfigValue<Boolean> showPvpVersion = setting(ConfigValues.ofBoolean("showPvpVersion", true));

	private final ModuleManager moduleManager;
	private final PvpVersionService pvpVersion;

	private List<class_2561> enabledModuleLabels = List.of();
	private boolean moduleListDirty = true;

	private class_2561 fpsLabel = class_2561.method_43473();
	private class_2561 coordinateLabel = class_2561.method_43473();
	private class_2561 pvpLabel = class_2561.method_43473();
	private String pvpLabelText = "";
	private double lastX;
	private double lastY;
	private double lastZ;
	private boolean coordinatesKnown;
	private int frames;

	/**
	 * @param moduleManager the registry the module list is read from
	 * @param eventBus      the bus the module list invalidation is driven by
	 * @param keyBinds      the factory used to register this module's key binding
	 * @param pvpVersion    the service that says which PvP rules the server runs with
	 */
	public HudModule(ModuleManager moduleManager, EventBus eventBus, KeyBindFactory keyBinds,
			PvpVersionService pvpVersion) {
		super("hud", "HUD", "Shows a status readout on the screen.", ModuleCategory.CLIENT);

		this.moduleManager = moduleManager;
		this.pvpVersion = pvpVersion;

		eventBus.subscribe(ModuleToggleEvent.class, event -> moduleListDirty = true);
		keyBinds.bind("hud", "key.birowo.hud", GLFW.GLFW_KEY_G, this::toggle);
	}

	@Override
	public void onTick() {
		if (!moduleListDirty) {
			return;
		}

		moduleListDirty = false;

		List<class_2561> labels = new ArrayList<>();

		for (Module module : moduleManager.enabledModules()) {
			labels.add(class_2561.method_43470(module.displayName()));
		}

		enabledModuleLabels = List.copyOf(labels);
	}

	@Override
	public void onHudRender(class_332 context, class_9779 tickCounter) {
		class_310 client = class_310.method_1551();
		class_327 textRenderer = client.field_1772;

		int x = this.x.value();
		int y = this.y.value();

		if (showFps.value()) {
			context.method_27535(textRenderer, fpsLabel(client), x, y, TEXT_COLOR);
			y += LINE_HEIGHT;
		}

		if (showCoordinates.value() && client.field_1724 != null) {
			context.method_27535(textRenderer, coordinates(client), x, y, TEXT_COLOR);
			y += LINE_HEIGHT;
		}

		if (showPvpVersion.value() && client.field_1724 != null) {
			context.method_27535(textRenderer, pvpVersionLabel(), x, y, TEXT_COLOR);
			y += LINE_HEIGHT;
		}

		if (showModules.value()) {
			for (class_2561 label : enabledModuleLabels) {
				context.method_27535(textRenderer, label, x, y, ACCENT_COLOR);
				y += LINE_HEIGHT;
			}
		}
	}
	@Override
	protected void onDisable() {
		coordinatesKnown = false;
		frames = 0;
	}

	/**
	 * @param client the client the frame rate is read from
	 * @return the label that shows the frame rate
	 */
	private class_2561 fpsLabel(class_310 client) {
		if (frames % FPS_INTERVAL_FRAMES == 0) {
			fpsLabel = class_2561.method_43470(client.method_47599() + " FPS");
		}

		frames++;

		return fpsLabel;
	}

	/**
	 * @return the label that shows the PvP rules that are in use
	 */
	private class_2561 pvpVersionLabel() {
		String text = "PvP " + pvpVersion.current().label();

		if (!text.equals(pvpLabelText)) {
			pvpLabelText = text;
			pvpLabel = class_2561.method_43470(text);
		}

		return pvpLabel;
	}

	/**
	 * @param client the client the position is read from
	 * @return the label that shows the position of the player
	 */
	private class_2561 coordinates(class_310 client) {
		double px = client.field_1724.method_23317();
		double py = client.field_1724.method_23318();
		double pz = client.field_1724.method_23321();

		if (!coordinatesKnown || px != lastX || py != lastY || pz != lastZ) {
			lastX = px;
			lastY = py;
			lastZ = pz;
			coordinatesKnown = true;

			coordinateLabel = class_2561.method_43470(String.format("%.1f %.1f %.1f", px, py, pz));
		}

		return coordinateLabel;
	}
}
