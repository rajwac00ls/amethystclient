package com.birowo.client.platform.command;

import com.birowo.client.core.command.Command;
import com.birowo.client.core.command.CommandManager;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Lists the available commands.
 */
public final class HelpCommand implements Command {
	private final CommandManager commandManager;

	/**
	 * @param commandManager the registry the commands are read from
	 */
	public HelpCommand(CommandManager commandManager) {
		this.commandManager = commandManager;
	}

	@Override
	public String name() {
		return "help";
	}

	@Override
	public String description() {
		return "Lists the available commands";
	}

	@Override
	public String usage() {
		return "";
	}

	@Override
	public boolean execute(String[] args) {
		StringBuilder message = new StringBuilder("Commands:");

		for (Command command : commandManager.commands()) {
			message.append(" .birowo ")
					.append(command.name());

			if (!command.usage().isEmpty()) {
				message.append(' ').append(command.usage());
			}

			message.append(" - ").append(command.description());
		}

		class_310 client = class_310.method_1551();

		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470("[Birowo] " + message), false);
		}

		return true;
	}
}
