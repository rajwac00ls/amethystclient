package com.birowo.client.platform.command;

import com.birowo.client.core.command.Command;
import com.birowo.client.core.module.Module;
import com.birowo.client.core.module.ModuleManager;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Lists every registered module and whether it is enabled.
 */
public final class ListCommand implements Command {
	private final ModuleManager moduleManager;

	/**
	 * @param moduleManager the registry the modules are read from
	 */
	public ListCommand(ModuleManager moduleManager) {
		this.moduleManager = moduleManager;
	}

	@Override
	public String name() {
		return "list";
	}

	@Override
	public String description() {
		return "Lists every module and its state";
	}

	@Override
	public String usage() {
		return "";
	}

	@Override
	public boolean execute(String[] args) {
		StringBuilder message = new StringBuilder("Modules:");

		for (Module module : moduleManager.modules()) {
			message.append(' ')
					.append(module.id())
					.append('=')
					.append(module.enabled() ? "on" : "off");
		}

		class_310 client = class_310.method_1551();

		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470("[Birowo] " + message), false);
		}

		return true;
	}
}
