package com.birowo.client.platform.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_5575;
import net.minecraft.class_638;
import net.minecraft.class_742;

/**
 * Finds the entities a module is allowed to act on.
 *
 * <p>Both lookups are index-backed, so they cost roughly what the target set costs rather than
 * what the whole world costs. The client must never iterate every loaded entity per frame.
 */
public final class EntityQueries {
	private EntityQueries() {
	}

	/**
	 * Finds the entities within a range of an origin that satisfy a predicate.
	 *
	 * @param world       the world to search
	 * @param origin      the entity the range is measured from
	 * @param range       the maximum distance, in blocks
	 * @param playersOnly whether to restrict the search to remote players
	 * @param predicate   the filter every candidate must satisfy
	 * @return the matching entities
	 */
	public static List<class_1297> entitiesInRange(class_638 world, class_1297 origin, double range,
			boolean playersOnly, Predicate<? super class_1297> predicate) {
		if (playersOnly) {
			List<class_1297> matches = new ArrayList<>();

			for (class_742 player : world.method_18456()) {
				if (predicate.test(player) && isWithinRange(origin, player, range)) {
					matches.add(player);
				}
			}

			return matches;
		}

		class_238 area = class_238.method_30048(origin.method_73189(), range, range, range);
		return world.method_18023(class_5575.method_31795(class_1297.class), area,
				entity -> predicate.test(entity) && isWithinRange(origin, entity, range));
	}

	/**
	 * @param origin the entity the distance is measured from
	 * @param target the entity being measured
	 * @param range  the maximum distance, in blocks
	 * @return whether the target is within range of the origin
	 */
	public static boolean isWithinRange(class_1297 origin, class_1297 target, double range) {
		return origin.method_5858(target) <= range * range;
	}
}
