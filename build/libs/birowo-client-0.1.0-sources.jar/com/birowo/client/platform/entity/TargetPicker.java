package com.birowo.client.platform.entity;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import com.birowo.client.platform.rotation.RotationEngine;

/**
 * Picks the target a module aims at.
 *
 * <p>The candidates are the entities a module has already collected; this class only decides
 * which of them is the better one, so that two modules with the same settings aim at the same
 * target.
 */
public final class TargetPicker {
	private TargetPicker() {
	}

	/**
	 * Picks the target that fits the given rule best.
	 *
	 * @param candidates the entities that may be aimed at
	 * @param origin     the entity that aims
	 * @param priority   the rule that decides between the candidates
	 * @return the chosen target, or {@code null} when there is no candidate at all
	 */
	public static class_1297 pick(List<class_1297> candidates, class_1297 origin, TargetPriority priority) {
		class_1297 best = null;
		double bestScore = Double.MAX_VALUE;

		for (class_1297 candidate : candidates) {
			double score = score(candidate, origin, priority);

			if (score < bestScore) {
				bestScore = score;
				best = candidate;
			}
		}

		return best;
	}

	/**
	 * @param candidate the entity that is scored
	 * @param origin    the entity that aims
	 * @param priority  the rule that decides between the candidates
	 * @return the score of the candidate; the lower the better
	 */
	private static double score(class_1297 candidate, class_1297 origin, TargetPriority priority) {
		switch (priority) {
			case HEALTH -> {
				if (candidate instanceof class_1309 living) {
					return living.method_6032();
				}

				return Double.MAX_VALUE;
			}
			case FIELD_OF_VIEW -> {
				return fieldOfViewDistance(origin, candidate);
			}
			case TYPE -> {
				return typeWeight(candidate);
			}
			case HURT_TIME -> {
				if (candidate instanceof class_1309 living) {
					// The lower the time of the last hit, the more recently the target was hurt.
					return living.field_6235;
				}

				return Double.MAX_VALUE;
			}
			case AGE -> {
				// The older the target, the smaller the score.
				return -candidate.field_6012;
			}
			default -> {
				return origin.method_5858(candidate);
			}
		}
	}

	/**
	 * @param candidate the entity that is weighed
	 * @return the weight of the kind of the entity; the lower the more wanted it is
	 */
	private static double typeWeight(class_1297 candidate) {
		if (candidate instanceof class_1657) {
			return 0.0D;
		}

		if (candidate instanceof class_1569) {
			return 1.0D;
		}

		return 2.0D;
	}

	/**
	 * @param origin the entity that looks
	 * @param target the entity that is looked at
	 * @return the angle between the direction the origin looks at and the target, in degrees
	 */
	public static double fieldOfViewDistance(class_1297 origin, class_1297 target) {
		class_243 eyes = origin.method_33571();
		class_243 point = target.method_33571();

		float yaw = RotationEngine.yawTo(eyes, point);
		float pitch = RotationEngine.pitchTo(eyes, point);

		double yawDifference = Math.abs(class_3532.method_15393(yaw - origin.method_36454()));
		double pitchDifference = Math.abs(pitch - origin.method_36455());

		return Math.sqrt(yawDifference * yawDifference + pitchDifference * pitchDifference);
	}

	/**
	 * @param origin the entity that looks
	 * @param target the entity that is looked at
	 * @param fov    the size of the cone the target has to lie in, in degrees
	 * @return whether the target lies inside the cone
	 */
	public static boolean inFieldOfView(class_1297 origin, class_1297 target, double fov) {
		return fieldOfViewDistance(origin, target) <= fov;
	}
}
