package com.birowo.client.platform.entity;

import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;

/**
 * Tells whether a target can be seen from where the player stands.
 */
public final class TargetVisibility {
	/**
	 * The slack of the check, in squared blocks. It keeps the block the player is standing in
	 * from counting as an obstacle.
	 */
	private static final double SLACK = 0.1D;

	private TargetVisibility() {
	}

	/**
	 * @param world  the world the ray travels through
	 * @param origin the entity that looks
	 * @param target the entity that is looked at
	 * @return whether nothing stands between the two
	 */
	public static boolean hasLineOfSight(class_638 world, class_1297 origin, class_1297 target) {
		class_243 start = origin.method_33571();
		class_243 end = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);

		class_3965 hit = world.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558,
				class_3959.class_242.field_1348, origin));

		if (hit.method_17783() == class_239.class_240.field_1333) {
			return true;
		}

		return start.method_1025(hit.method_17784()) >= start.method_1025(end) - SLACK;
	}
}
