package com.birowo.client.platform.gui;

import com.birowo.client.core.gui.ClickGuiHost;
import com.birowo.client.core.gui.GuiScreenLauncher;
import net.minecraft.class_310;

/**
 * Opens the interface on the screen of the game.
 *
 * <p>The launcher owns the screen that is currently open, so that the interface can be closed
 * again without the caller having to know how it was opened.
 */
public final class MinecraftGuiScreenLauncher implements GuiScreenLauncher {
	private ClickGuiScreen screen;

	@Override
	public void open(ClickGuiHost host) {
		class_310 client = class_310.method_1551();
		ClickGuiScreen opened = new ClickGuiScreen(client, host);

		screen = opened;
		client.method_1507(opened);
	}

	@Override
	public void close() {
		class_310 client = class_310.method_1551();

		if (screen != null && client.field_1755 == screen) {
			screen.requestClose();
		}
	}
}
