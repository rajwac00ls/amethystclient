package com.birowo.client.platform.keybind;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import com.birowo.client.core.keybind.KeyBind;
import com.birowo.client.core.keybind.KeyBindFactory;

/**
 * Creates Minecraft key bindings and dispatches their press events.
 *
 * <p>The manager is the single owner of every binding it creates. Presses are consumed here, once
 * per tick, so a module can never steal a press from the action it registered.
 */
public final class KeyBindManager implements KeyBindFactory {
	private final class_304.class_11900 category;
	private final List<PlatformKeyBind> bindings = new ArrayList<>();

	/**
	 * @param categoryPath the path of the key bind category, relative to the {@code birowo}
	 *                     namespace
	 */
	public KeyBindManager(String categoryPath) {
		this.category = class_304.class_11900.method_74698(class_2960.method_60655("birowo", categoryPath));
	}

	@Override
	public KeyBind bind(String id, String translationKey, int defaultKeyCode, Runnable onPressed) {
		class_304 binding = new class_304(translationKey, defaultKeyCode, category);
		KeyBindingHelper.registerKeyBinding(binding);

		PlatformKeyBind keyBind = new PlatformKeyBind(id, binding, onPressed);
		bindings.add(keyBind);
		return keyBind;
	}

	/**
	 * Dispatches the press of every binding that was pressed since the last tick.
	 */
	public void onTick() {
		for (PlatformKeyBind binding : bindings) {
			if (binding.wasPressed()) {
				binding.press();
			}
		}
	}
}
