package com.birowo.client.platform.keybind;

import com.birowo.client.core.keybind.KeyBind;
import net.minecraft.class_304;

/**
 * A {@link KeyBind} backed by a Minecraft key binding.
 */
public final class PlatformKeyBind implements KeyBind {
	private final String id;
	private final class_304 binding;
	private final Runnable action;

	PlatformKeyBind(String id, class_304 binding, Runnable action) {
		this.id = id;
		this.binding = binding;
		this.action = action;
	}

	@Override
	public String id() {
		return id;
	}

	/**
	 * @return whether the key was pressed since the last call, consuming the press
	 */
	boolean wasPressed() {
		return binding.method_1436();
	}

	/**
	 * Runs the action bound to this key.
	 */
	void press() {
		action.run();
	}
}
