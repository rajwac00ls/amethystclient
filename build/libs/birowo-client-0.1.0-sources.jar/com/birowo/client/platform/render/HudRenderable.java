package com.birowo.client.platform.render;

import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Implemented by modules that draw on the HUD layer.
 */
public interface HudRenderable {
	/**
	 * Draws on the HUD.
	 *
	 * @param context     the draw context of the current frame
	 * @param tickCounter the tick counter of the current frame
	 */
	void onHudRender(class_332 context, class_9779 tickCounter);
}
