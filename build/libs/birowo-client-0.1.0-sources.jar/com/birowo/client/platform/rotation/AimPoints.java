package com.birowo.client.platform.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

/**
 * The point of a target that a module asks for.
 *
 * <p>The point is taken from the place the target is drawn at, so that the aim follows the
 * target smoothly between two ticks instead of jumping once per tick.
 */
public final class AimPoints {
	private AimPoints() {
	}

	/**
	 * The point of the target that was asked for.
	 *
	 * @param target     the entity that is aimed at
	 * @param aimPoint   the part of the target that is aimed at
	 * @param multipoint how far the point lies between the centre of the body and the point that
	 *                   was asked for, as a percentage
	 * @param eyes       where the player looks from, in world coordinates
	 * @return the point in world coordinates
	 */
	public static class_243 base(class_1297 target, AimPoint aimPoint, float multipoint, class_243 eyes) {
		class_310 client = class_310.method_1551();
		float delta = client.method_61966().method_60637(false);
		class_243 position = target.method_30950(delta);

		double half = target.method_17681() / 2.0D;
		double height = target.method_17682();

		double minX = position.field_1352 - half;
		double maxX = position.field_1352 + half;
		double minY = position.field_1351;
		double maxY = position.field_1351 + height;
		double minZ = position.field_1350 - half;
		double maxZ = position.field_1350 + half;

		double centerX = (minX + maxX) / 2.0D;
		double centerY = (minY + maxY) / 2.0D;
		double centerZ = (minZ + maxZ) / 2.0D;

		double x = centerX;
		double y = centerY;
		double z = centerZ;

		switch (aimPoint) {
			case HEAD -> y = maxY - 0.1D;
			case FEET -> y = minY + 0.1D;
			case CLOSEST -> {
				x = Math.max(minX, Math.min(eyes.field_1352, maxX));
				y = Math.max(minY, Math.min(eyes.field_1351, maxY));
				z = Math.max(minZ, Math.min(eyes.field_1350, maxZ));
			}
			case BODY -> {
			}
		}

		float factor = class_3532.method_15363(multipoint / 100.0F, 0.0F, 1.0F);

		return new class_243(centerX + (x - centerX) * factor,
				centerY + (y - centerY) * factor,
				centerZ + (z - centerZ) * factor);
	}
}
