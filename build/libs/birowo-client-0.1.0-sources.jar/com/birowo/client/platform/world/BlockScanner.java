package com.birowo.client.platform.world;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2826;
import net.minecraft.class_638;

/**
 * Looks through the chunks of the world for the blocks that are worth showing.
 *
 * <p>A chunk is made of sections of sixteen by sixteen by sixteen blocks. A section that holds
 * none of the blocks that are looked for is skipped without being read, because that check only
 * walks through the few kinds of block the section is made of.
 *
 * <p>The scanner is not meant to be run over the whole world at once: a chunk holds thousands of
 * blocks. The caller decides how many chunks are looked through in one tick.
 */
public final class BlockScanner {
	/**
	 * The height, the width and the depth of a section, in blocks.
	 */
	private static final int SECTION_SIZE = 16;

	private BlockScanner() {
	}

	/**
	 * Looks through one chunk for the blocks that are wanted.
	 *
	 * @param world  the world the chunk is in, used to read the shape of the blocks
	 * @param chunk  the chunk that is looked through
	 * @param wanted the blocks that are looked for
	 * @return the outlines of the blocks that were found, in world coordinates
	 */
	public static List<class_238> scan(class_638 world, class_2791 chunk, Set<class_2248> wanted) {
		List<class_238> found = new ArrayList<>();
		class_1923 position = chunk.method_12004();
		class_2338.class_2339 cursor = new class_2338.class_2339();
		class_2826[] sections = chunk.method_12006();
		int bottom = world.method_31607();

		for (int index = 0; index < sections.length; index++) {
			class_2826 section = sections[index];

			if (section.method_38292() || !section.method_19523(state -> wanted.contains(state.method_26204()))) {
				continue;
			}

			int baseY = bottom + index * SECTION_SIZE;

			for (int y = 0; y < SECTION_SIZE; y++) {
				for (int x = 0; x < SECTION_SIZE; x++) {
					for (int z = 0; z < SECTION_SIZE; z++) {
						class_2680 state = section.method_12254(x, y, z);

						if (!wanted.contains(state.method_26204())) {
							continue;
						}

						cursor.method_10103(position.method_8326() + x, baseY + y, position.method_8328() + z);
						found.add(outline(world, cursor, state));
					}
				}
			}
		}

		return found;
	}

	/**
	 * The outline of one block.
	 *
	 * @param world the world the block is in
	 * @param pos   the place of the block, in world coordinates
	 * @param state the state of the block
	 * @return the outline of the block, in world coordinates
	 */
	private static class_238 outline(class_638 world, class_2338 pos, class_2680 state) {
		class_265 shape = state.method_26218(world, pos);

		if (shape.method_1110()) {
			return new class_238(pos);
		}

		return shape.method_1107().method_996(pos);
	}
}
