/*
 * Copyright (c) 2023 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.filament.nameproposal;

import java.util.List;

import net.fabricmc.filament.nameproposal.field.nameprovider.ConditionalFieldNameProvider;
import net.fabricmc.filament.nameproposal.field.nameprovider.ConstantFieldNameProvider;
import net.fabricmc.filament.nameproposal.field.nameprovider.FieldNameProvider;
import net.fabricmc.filament.nameproposal.field.nameprovider.SequenceFieldNameProvider;
import net.fabricmc.filament.nameproposal.field.nameprovider.StringArgumentFieldNameProvider;
import net.fabricmc.filament.nameproposal.field.predicate.DescriptorFieldPredicate;
import net.fabricmc.filament.nameproposal.field.predicate.InternalInitFieldPredicate;
import net.fabricmc.filament.nameproposal.field.predicate.StaticFieldPredicate;

public record NameProposalConfig(FieldNameProvider fieldNameProvider) {
	public static final NameProposalConfig DEFAULT = new NameProposalConfig(new SequenceFieldNameProvider(List.of(
			new ConditionalFieldNameProvider(
					StringArgumentFieldNameProvider.INSTANCE,
					List.of(
							new StaticFieldPredicate(true),
							InternalInitFieldPredicate.INSTANCE
					)
			),
			new ConditionalFieldNameProvider(
					new ConstantFieldNameProvider("CODEC"),
					List.of(
							new StaticFieldPredicate(true),
							new DescriptorFieldPredicate("Lcom/mojang/serialization/Codec;")
					)
			),
			new ConditionalFieldNameProvider(
					new ConstantFieldNameProvider("CODEC"),
					List.of(
							new StaticFieldPredicate(true),
							new DescriptorFieldPredicate("Lcom/mojang/serialization/MapCodec;")
					)
			)
	)));
}
